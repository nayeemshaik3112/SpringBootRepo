package com.luv2code.springboot.todos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TodosApplicationTests {

	@Test
	void contextLoads() {
	}

}
