package SpringBootProject1.Project_1_Books;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project1BooksApplicationTests {

	@Test
	void contextLoads() {
	}

}
