package SpringBootProject1.Project_1_Books;

import jakarta.annotation.PostConstruct;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping(value = "/books")
public class BookController {

    private final List<Book> books = new ArrayList<>();

    @PostConstruct
    public void intiliaze(){
        books.addAll(List.of(
                new Book(1,"author1", "category1", "title1"),
                new Book(2,"author2", "category2", "title2")));
    }


    @GetMapping
    public List<Book> getallbooks(@RequestParam(required = false) String category){
        if (category == null) return books;
        return books.stream().filter(book -> book.getCategory().equalsIgnoreCase(category)).toList();
    }

//    @GetMapping(value = "/{title}")
//    public Book getmybook(@PathVariable String title){
//       return  books.stream().
//               filter(book -> book.getTitle().equalsIgnoreCase(title)).
//               findFirst().orElse(null);
//    }

    @GetMapping(value = "/{id}")
    public Book getmybook(@PathVariable int id, @RequestParam(required = false) String title){
        return  books.stream().
                filter(book -> book.getId() == id && book.getTitle().equalsIgnoreCase(title)).findFirst().orElse(null);
    }

    @PostMapping
    public void addbook (@RequestBody Book Newbook){
         boolean NewBook = books.stream().
                          noneMatch(book -> book.getTitle().equalsIgnoreCase(Newbook.getTitle()));

         if (NewBook) {
             books.add(Newbook);
         }
    }

    @PutMapping("/{id}")
    public Book update(@PathVariable int id, @RequestBody Book updatedBook) {
        for (Book book : books) {
            if (book.getId() == id) {
                book.setAuthor(updatedBook.getAuthor());
                book.setCategory(updatedBook.getCategory());
                book.setTitle(updatedBook.getTitle());
                return book;
            }
        }
        throw new RuntimeException("Book not found");
    }

    @DeleteMapping(value = "{id}")
    public void delete(@PathVariable int id){
        books.removeIf(book -> book.getId() == id);


    }
}
