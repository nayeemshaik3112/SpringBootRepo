package SpringBootProject1.Project_1_Books;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Project1BooksApplication {

	public static void main(String[] args)
	{
		SpringApplication.run(Project1BooksApplication.class, args);
	}

}
